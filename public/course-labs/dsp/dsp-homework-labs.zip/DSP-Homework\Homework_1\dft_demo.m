% 一般模拟信号的DFT处理过程演示
% 作者: Trae AI
% 描述: 本程序演示了连续模拟信号经过采样、截断、加窗以及离散傅里叶变换(DFT)的全过程。

clear; clc; close all;

%% 1. 模拟信号参数设置 (构造一个连续信号)
% 构造一个包含 50Hz 和 120Hz 两个频率分量的混合信号
f1 = 50;  % 频率分量1: 50Hz
f2 = 120; % 频率分量2: 120Hz

% 使用极小的时间步长来近似表示“连续”的模拟信号
t_continuous = 0:0.0001:0.1; 
x_continuous = 0.7*sin(2*pi*f1*t_continuous) + sin(2*pi*f2*t_continuous);

%% 2. 采样过程
% 根据奈奎斯特采样定理，采样频率 fs 必须大于信号最高频率的两倍 (fs > 2 * 120 = 240Hz)
fs = 500; % 这里设定采样频率为 500Hz
Ts = 1/fs; % 采样周期

% 取 N 个采样点
N = 256; % 截断长度/DFT点数
t_discrete = (0:N-1)*Ts; % 离散时间序列
x_discrete = 0.7*sin(2*pi*f1*t_discrete) + sin(2*pi*f2*t_discrete); % 理想采样后的离散信号

%% 3. 加窗与截断
% 这里默认使用矩形窗（即直接截断）。如果需要减少频谱泄漏，可以使用汉明窗等。
% 例如：x_windowed = x_discrete .* hamming(N)';
x_windowed = x_discrete; 

%% 4. DFT (FFT) 计算
% 使用 MATLAB 的快速傅里叶变换(FFT)函数计算DFT
X_k = fft(x_windowed, N);

% 计算双边幅度谱并进行归一化（除以N）
mag_X = abs(X_k) / N; 

% 计算单边幅度谱 (直流分量和奈奎斯特频率除外需乘以2以补偿能量)
mag_X_single = mag_X(1:N/2+1);
mag_X_single(2:end-1) = 2 * mag_X_single(2:end-1);

% 构建频率轴 (分辨率为 fs/N)
f_axis = (0:N/2) * (fs/N);

%% 5. 绘图展示
figure('Name', '一般模拟信号的DFT处理过程演示', 'Position', [100, 100, 800, 600]);

% 子图1：原始连续模拟信号
subplot(3,1,1);
plot(t_continuous, x_continuous, 'b', 'LineWidth', 1.2);
title('步骤1：原始连续模拟信号 (50Hz与120Hz混合)');
xlabel('时间 (s)'); ylabel('幅度');
grid on;

% 子图2：采样后的离散时间信号
subplot(3,1,2);
stem(t_discrete(1:50), x_discrete(1:50), 'r', 'filled'); % 只显示前50个点以便于观察
title('步骤2 & 3：采样并截断后的离散时间信号 (显示前50个点)');
xlabel('时间 (s)'); ylabel('幅度');
grid on;

% 子图3：DFT(FFT) 得到的单边幅度谱
subplot(3,1,3);
plot(f_axis, mag_X_single, 'k', 'LineWidth', 1.5);
hold on;
% 标出峰值点
stem(f_axis, mag_X_single, 'k', 'Marker', 'none'); 
title(['步骤4：DFT得到的单边幅度谱 (N=', num2str(N), ', fs=', num2str(fs), 'Hz)']);
xlabel('频率 (Hz)'); ylabel('幅度');
xlim([0, fs/2]);
grid on;

disp('DFT处理过程演示完毕！请查看生成的图形窗口。');
