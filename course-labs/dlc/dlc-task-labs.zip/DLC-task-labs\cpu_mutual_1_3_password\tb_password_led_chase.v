`timescale 1ns / 1ps

module tb_password_led_chase;
    reg clk;
    reg rstn;
    reg [15:0] sw_i;
    wire [15:0] led_o;
    wire [3:0] debug_index;

    password_led_chase #(
        .DIV_MAX(5)
    ) uut (
        .clk(clk),
        .rstn(rstn),
        .sw_i(sw_i),
        .led_o(led_o),
        .debug_index(debug_index)
    );

    always #5 clk = ~clk;

    task wait_for_index;
        input [3:0] expected_index;
        integer cycles;
        begin
            cycles = 0;
            while (debug_index !== expected_index && cycles < 40) begin
                @(posedge clk);
                cycles = cycles + 1;
            end
            #1;
            if (debug_index !== expected_index) begin
                $display("FAIL: timeout waiting for index %0d, got %0d led=%h", expected_index, debug_index, led_o);
                $fatal;
            end
        end
    endtask

    initial begin
        clk = 0;
        rstn = 0;
        sw_i = 16'b0;
        #20;
        rstn = 1;

        sw_i[3:0] = 4'b0011;
        repeat (8) @(posedge clk);
        #1;
        if (led_o !== 16'h0000) begin
            $display("FAIL: wrong password should keep LEDs off");
            $fatal;
        end

        sw_i[3:0] = 4'b1010;
        #10;
        if (led_o !== 16'h8000) begin
            $display("FAIL: correct password should start at led[15], got %h", led_o);
            $fatal;
        end

        wait_for_index(4'd14);
        if (led_o !== 16'h4000) begin
            $display("FAIL: first chase step expected led[14], got %h", led_o);
            $fatal;
        end

        wait_for_index(4'd13);
        if (led_o !== 16'h2000) begin
            $display("FAIL: second chase step expected led[13], got %h", led_o);
            $fatal;
        end

        sw_i[3:0] = 4'b0000;
        #20;
        if (led_o !== 16'h0000 || debug_index !== 4'd15) begin
            $display("FAIL: password removal should clear LEDs and reset index");
            $fatal;
        end

        $display("PASS: password_led_chase behavior passed");
        $finish;
    end
endmodule
