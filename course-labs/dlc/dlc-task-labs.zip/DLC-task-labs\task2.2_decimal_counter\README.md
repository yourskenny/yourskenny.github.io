﻿# 任务 4：0-9 十进制计数器

## 交付物

- `design_report.md`：状态流程、分频和显示说明。
- `decimal_counter.v`：参数化分频计数器。
- `tb_decimal_counter.v`：自检仿真。
- `hardware_verification.md`：开发板验证步骤。

## 推荐仿真命令

```powershell
iverilog -g2012 -o tb_decimal_counter.vvp decimal_counter.v tb_decimal_counter.v
vvp tb_decimal_counter.vvp
```

期望输出：

```text
PASS: decimal_counter behavior passed
```
