`timescale 1ns / 1ps

// 任务1：举重比赛裁判逻辑
// 根据数逻课程项目规范，严格执行先列真值表再化简的流程，
// 并且严禁直接在逻辑代码中使用约束文件变量(sw_i, led_o)。

module weightlifting_judge(
    input  [2:0] sw_i, // sw_i[0]代表主裁判, sw_i[1],sw_i[2]代表两名副裁判
    output [0:0] led_o // led_o[0]代表最终判定结果灯
);

    // 1. 根据红线警告，定义具有实际意义的内部变量名，避免直接使用 sw_i[x] 进行逻辑操作
    wire main_ref;   // A: 主裁判
    wire sub_ref1;   // B: 副裁判1
    wire sub_ref2;   // C: 副裁判2
    wire valid_result; // F: 合格信号灯判定结果
    
    // 2. 将外部物理接口信号分配给内部变量
    assign main_ref = sw_i[0];
    assign sub_ref1 = sw_i[1];
    assign sub_ref2 = sw_i[2];
    
    // 3. 逻辑实现：
    // 根据真值表化简得出最简表达式：F = A(B+C) = AB + AC
    // 题目建议尽量使用与非门(NAND)，所以通过德摩根定律变形：
    // F = ( (AB)' * (AC)' )' 
    
    // 中间信号，用于存储与非门的中间结果
    wire nand_ab;
    wire nand_ac;
    
    // (AB)' = nand(A, B)
    nand (nand_ab, main_ref, sub_ref1);
    
    // (AC)' = nand(A, C)
    nand (nand_ac, main_ref, sub_ref2);
    
    // F = ( (AB)' * (AC)' )' = nand( (AB)', (AC)' )
    nand (valid_result, nand_ab, nand_ac);
    
    // 4. 将逻辑结果输出到物理接口
    assign led_o[0] = valid_result;

endmodule
