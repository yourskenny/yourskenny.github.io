﻿# 计组互认任务 4-5：数码管固定显示与矩形动画

## 文件清单

- `seg7x16.v`：8 位数码管动态扫描与 16 进制译码公共模块。
- `seg7_top_fixed.v`：任务 4，固定显示 `76543210`；`seg7_top_fixed_board` 是上板顶层。
- `rectangle_animation.v`：任务 5，使用 64 位图形段码实现矩形动画；`rectangle_animation_top` 是上板顶层。
- `tb_seg_display.v`：任务 4-5 的自检仿真。
- `seg7_fixed.xdc`、`rectangle_animation.xdc`：上板约束。

## 验证命令

```powershell
& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv seg7x16.v seg7_top_fixed.v rectangle_animation.v tb_seg_display.v
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_seg_display -s tb_seg_display_sim
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' tb_seg_display_sim -runall
```

期望输出：

```text
PASS: seg display mutual tasks passed
```

## 上板观察

- 固定显示工程：复位释放后，8 位数码管应从左到右显示 `76543210`。
- 矩形动画工程：`sw_i[0] = 1` 时右侧四位数码管播放矩形动画，`sw_i[0] = 0` 时熄灭并回到第一帧。
