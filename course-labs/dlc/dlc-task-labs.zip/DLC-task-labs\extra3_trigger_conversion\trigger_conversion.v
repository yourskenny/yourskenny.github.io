`timescale 1ns / 1ps

module dff_for_conversion(
    input clk,
    input rstn,
    input d,
    output reg q
);
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            q <= 1'b0;
        end else begin
            q <= d;
        end
    end
endmodule

module jkff_basic(
    input clk,
    input rstn,
    input j,
    input k,
    output reg q
);
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            q <= 1'b0;
        end else begin
            case ({j, k})
                2'b00: q <= q;
                2'b01: q <= 1'b0;
                2'b10: q <= 1'b1;
                2'b11: q <= ~q;
            endcase
        end
    end
endmodule

// Conversion 1: implement a T flip-flop with a D flip-flop.
// T=0 holds Q, T=1 toggles Q, so D = T xor Q.
module t_by_dff(
    input clk,
    input rstn,
    input t,
    output q
);
    wire d_next;

    assign d_next = t ^ q;

    dff_for_conversion ff (
        .clk(clk),
        .rstn(rstn),
        .d(d_next),
        .q(q)
    );
endmodule

// Conversion 2: implement a JK flip-flop with a D flip-flop.
// The conversion logic is D = J & ~Q | ~K & Q.
module jk_by_dff(
    input clk,
    input rstn,
    input j,
    input k,
    output q
);
    wire d_next;

    assign d_next = (j & ~q) | (~k & q);

    dff_for_conversion ff (
        .clk(clk),
        .rstn(rstn),
        .d(d_next),
        .q(q)
    );
endmodule

// Conversion 3: implement a D flip-flop with a JK flip-flop.
// To capture D, drive J=D and K=~D.
module d_by_jkff(
    input clk,
    input rstn,
    input d,
    output q
);
    wire j_drive;
    wire k_drive;

    assign j_drive = d;
    assign k_drive = ~d;

    jkff_basic ff (
        .clk(clk),
        .rstn(rstn),
        .j(j_drive),
        .k(k_drive),
        .q(q)
    );
endmodule

module trigger_conversion_top(
    input clk,
    input rstn,
    input d_in,
    input t_in,
    input j_in,
    input k_in,
    output q_t_by_d,
    output q_jk_by_d,
    output q_d_by_jk
);
    t_by_dff u_t_by_d (
        .clk(clk),
        .rstn(rstn),
        .t(t_in),
        .q(q_t_by_d)
    );

    jk_by_dff u_jk_by_d (
        .clk(clk),
        .rstn(rstn),
        .j(j_in),
        .k(k_in),
        .q(q_jk_by_d)
    );

    d_by_jkff u_d_by_jk (
        .clk(clk),
        .rstn(rstn),
        .d(d_in),
        .q(q_d_by_jk)
    );
endmodule

module seg7_binary01(
    input q,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    assign disp_an_o = 8'b1111_1110;
    assign disp_seg_o = q ? 8'hF9 : 8'hC0;
endmodule

module btnc_one_pulse #(
    parameter DEBOUNCE_MAX = 20'd999_999
)(
    input clk,
    input rstn,
    input btn,
    output reg pulse
);
    reg btn_meta;
    reg btn_sync;
    reg btn_stable;
    reg [19:0] stable_count;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            btn_meta <= 1'b0;
            btn_sync <= 1'b0;
            btn_stable <= 1'b0;
            stable_count <= 20'd0;
            pulse <= 1'b0;
        end else begin
            btn_meta <= btn;
            btn_sync <= btn_meta;
            pulse <= 1'b0;

            if (btn_sync == btn_stable) begin
                stable_count <= 20'd0;
            end else if (stable_count == DEBOUNCE_MAX) begin
                btn_stable <= btn_sync;
                stable_count <= 20'd0;
                pulse <= btn_sync;
            end else begin
                stable_count <= stable_count + 20'd1;
            end
        end
    end
endmodule

module t_by_dff_step(
    input clk,
    input rstn,
    input step_en,
    input t,
    output reg q
);
    wire d_next;

    assign d_next = t ^ q;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            q <= 1'b0;
        end else if (step_en) begin
            q <= d_next;
        end
    end
endmodule

module jk_by_dff_step(
    input clk,
    input rstn,
    input step_en,
    input j,
    input k,
    output reg q
);
    wire d_next;

    assign d_next = (j & ~q) | (~k & q);

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            q <= 1'b0;
        end else if (step_en) begin
            q <= d_next;
        end
    end
endmodule

module d_by_jkff_step(
    input clk,
    input rstn,
    input step_en,
    input d,
    output reg q
);
    wire j_drive;
    wire k_drive;

    assign j_drive = d;
    assign k_drive = ~d;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            q <= 1'b0;
        end else if (step_en) begin
            case ({j_drive, k_drive})
                2'b00: q <= q;
                2'b01: q <= 1'b0;
                2'b10: q <= 1'b1;
                2'b11: q <= ~q;
            endcase
        end
    end
endmodule

module extra3_t_by_dff_top(
    input clk,
    input BTNC,
    input rstn,
    input [15:0] sw_i,
    output [15:0] led_o,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    wire q;
    wire step_pulse;

    btnc_one_pulse u_step (
        .clk(clk),
        .rstn(rstn),
        .btn(BTNC),
        .pulse(step_pulse)
    );

    t_by_dff_step u_conversion (
        .clk(clk),
        .rstn(rstn),
        .step_en(step_pulse),
        .t(sw_i[0]),
        .q(q)
    );

    seg7_binary01 u_display (
        .q(q),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o)
    );

    assign led_o[0] = q;
    assign led_o[14] = sw_i[0];
    assign led_o[15] = 1'b0;
    assign led_o[13:1] = 13'b0;
endmodule

module extra3_jk_by_dff_top(
    input clk,
    input BTNC,
    input rstn,
    input [15:0] sw_i,
    output [15:0] led_o,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    wire q;
    wire step_pulse;

    btnc_one_pulse u_step (
        .clk(clk),
        .rstn(rstn),
        .btn(BTNC),
        .pulse(step_pulse)
    );

    jk_by_dff_step u_conversion (
        .clk(clk),
        .rstn(rstn),
        .step_en(step_pulse),
        .j(sw_i[0]),
        .k(sw_i[1]),
        .q(q)
    );

    seg7_binary01 u_display (
        .q(q),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o)
    );

    assign led_o[0] = q;
    assign led_o[14] = sw_i[1];
    assign led_o[15] = sw_i[0];
    assign led_o[13:1] = 13'b0;
endmodule

module extra3_d_by_jkff_top(
    input clk,
    input BTNC,
    input rstn,
    input [15:0] sw_i,
    output [15:0] led_o,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    wire q;
    wire step_pulse;

    btnc_one_pulse u_step (
        .clk(clk),
        .rstn(rstn),
        .btn(BTNC),
        .pulse(step_pulse)
    );

    d_by_jkff_step u_conversion (
        .clk(clk),
        .rstn(rstn),
        .step_en(step_pulse),
        .d(sw_i[0]),
        .q(q)
    );

    seg7_binary01 u_display (
        .q(q),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o)
    );

    assign led_o[0] = q;
    assign led_o[14] = sw_i[0];
    assign led_o[15] = 1'b0;
    assign led_o[13:1] = 13'b0;
endmodule
