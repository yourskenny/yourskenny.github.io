`timescale 1ns / 1ps

module tb_bcd_detector;
    reg [3:0] sw_i;
    wire [1:0] led_o;

    integer i;
    reg expected_f1;
    reg expected_f2;

    bcd_detector uut (
        .sw_i(sw_i),
        .led_o(led_o)
    );

    initial begin
        for (i = 0; i < 10; i = i + 1) begin
            sw_i = i[3:0];
            #10;
            expected_f1 = (i > 3);
            expected_f2 = (i < 7);
            if (led_o[0] !== expected_f1 || led_o[1] !== expected_f2) begin
                $display("FAIL: input=%0d expected F1F2=%b%b got=%b%b",
                         i, expected_f1, expected_f2, led_o[0], led_o[1]);
                $finish;
            end
        end

        $display("PASS: bcd_detector valid BCD cases passed");
        $finish;
    end
endmodule
