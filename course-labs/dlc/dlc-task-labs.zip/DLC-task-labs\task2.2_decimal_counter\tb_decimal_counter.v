`timescale 1ns / 1ps

module tb_decimal_counter;
    reg clk;
    reg rstn;
    reg [15:0] sw_i;
    wire [7:0] disp_an_o;
    wire [7:0] disp_seg_o;
    wire [3:0] debug_count;

    decimal_counter #(
        .DIV_MAX(3)
    ) uut (
        .clk(clk),
        .rstn(rstn),
        .sw_i(sw_i),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_count(debug_count)
    );

    always #5 clk = ~clk;

    task wait_count_tick;
        begin
            repeat (8) @(posedge clk);
        end
    endtask

    task wait_for_count;
        input [3:0] expected_count;
        integer guard;
        begin
            guard = 0;
            while (debug_count !== expected_count && guard < 80) begin
                @(posedge clk);
                #1;
                guard = guard + 1;
            end
            if (debug_count !== expected_count) begin
                $display("FAIL: timeout waiting for count %0d, got %0d", expected_count, debug_count);
                $finish;
            end
        end
    endtask

    initial begin
        clk = 0;
        rstn = 0;
        sw_i = 16'b0;
        #20;
        rstn = 1;

        if (disp_seg_o !== 8'hFF || debug_count !== 4'd0) begin
            $display("FAIL: EN=0 should blank and clear");
            $finish;
        end

        sw_i[15] = 1'b1;
        wait_for_count(4'd1);

        wait_for_count(4'd0);

        wait_for_count(4'd1);
        sw_i[15] = 1'b0;
        #20;
        if (debug_count !== 4'd0 || disp_seg_o !== 8'hFF) begin
            $display("FAIL: disabling EN should clear and blank");
            $finish;
        end

        sw_i[15] = 1'b1;
        wait_count_tick();
        rstn = 1'b0;
        #20;
        rstn = 1'b1;
        if (debug_count !== 4'd0) begin
            $display("FAIL: reset should clear counter");
            $finish;
        end

        $display("PASS: decimal_counter behavior passed");
        $finish;
    end
endmodule
