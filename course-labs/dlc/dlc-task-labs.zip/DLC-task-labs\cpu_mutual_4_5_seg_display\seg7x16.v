`timescale 1ns / 1ps

module seg7x16 #(
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    input [31:0] i_data,
    input [7:0] i_blank,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o,
    output [2:0] debug_addr,
    output [3:0] debug_nibble
);
    reg [15:0] scan_counter;
    reg [2:0] seg7_addr;
    reg [3:0] current_nibble;
    reg [7:0] an_reg;
    reg [7:0] seg_reg;

    assign debug_addr = seg7_addr;
    assign debug_nibble = current_nibble;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            scan_counter <= 16'd0;
            seg7_addr <= 3'd0;
        end else if (scan_counter == SCAN_DIV_MAX) begin
            scan_counter <= 16'd0;
            seg7_addr <= seg7_addr + 3'd1;
        end else begin
            scan_counter <= scan_counter + 16'd1;
        end
    end

    always @(*) begin
        case (seg7_addr)
            3'd0: current_nibble = i_data[3:0];
            3'd1: current_nibble = i_data[7:4];
            3'd2: current_nibble = i_data[11:8];
            3'd3: current_nibble = i_data[15:12];
            3'd4: current_nibble = i_data[19:16];
            3'd5: current_nibble = i_data[23:20];
            3'd6: current_nibble = i_data[27:24];
            3'd7: current_nibble = i_data[31:28];
        endcase

        an_reg = ~(8'b0000_0001 << seg7_addr);

        if (i_blank[seg7_addr]) begin
            seg_reg = 8'hFF;
        end else begin
            case (current_nibble)
                4'h0: seg_reg = 8'hC0;
                4'h1: seg_reg = 8'hF9;
                4'h2: seg_reg = 8'hA4;
                4'h3: seg_reg = 8'hB0;
                4'h4: seg_reg = 8'h99;
                4'h5: seg_reg = 8'h92;
                4'h6: seg_reg = 8'h82;
                4'h7: seg_reg = 8'hF8;
                4'h8: seg_reg = 8'h80;
                4'h9: seg_reg = 8'h90;
                4'hA: seg_reg = 8'h88;
                4'hB: seg_reg = 8'h83;
                4'hC: seg_reg = 8'hC6;
                4'hD: seg_reg = 8'hA1;
                4'hE: seg_reg = 8'h86;
                4'hF: seg_reg = 8'h8E;
            endcase
        end
    end

    assign disp_an_o = an_reg;
    assign disp_seg_o = seg_reg;
endmodule
