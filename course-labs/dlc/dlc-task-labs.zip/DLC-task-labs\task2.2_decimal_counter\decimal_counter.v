`timescale 1ns / 1ps

// 任务4：0-9十进制计数器
// sw_i[15] 为 EN；rstn 为低电平有效复位；EN=0 时清零并全灭。

module decimal_counter #(
    parameter DIV_MAX = 27'd99_999_999
)(
    input clk,
    input rstn,
    input [15:0] sw_i,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o,
    output [3:0] debug_count
);

    wire enable_count;
    reg [26:0] div_counter;
    reg tick;
    reg [3:0] current_count;
    reg [7:0] segment_code;

    assign enable_count = sw_i[15];
    assign debug_count = current_count;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            div_counter <= 27'd0;
            tick <= 1'b0;
        end else if (!enable_count) begin
            div_counter <= 27'd0;
            tick <= 1'b0;
        end else if (div_counter == DIV_MAX) begin
            div_counter <= 27'd0;
            tick <= 1'b1;
        end else begin
            div_counter <= div_counter + 27'd1;
            tick <= 1'b0;
        end
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            current_count <= 4'd0;
        end else if (!enable_count) begin
            current_count <= 4'd0;
        end else if (tick) begin
            if (current_count == 4'd9) begin
                current_count <= 4'd0;
            end else begin
                current_count <= current_count + 4'd1;
            end
        end
    end

    always @(*) begin
        if (!enable_count) begin
            segment_code = 8'hFF;
        end else begin
            case (current_count)
                4'd0: segment_code = 8'hC0;
                4'd1: segment_code = 8'hF9;
                4'd2: segment_code = 8'hA4;
                4'd3: segment_code = 8'hB0;
                4'd4: segment_code = 8'h99;
                4'd5: segment_code = 8'h92;
                4'd6: segment_code = 8'h82;
                4'd7: segment_code = 8'hF8;
                4'd8: segment_code = 8'h80;
                4'd9: segment_code = 8'h90;
                default: segment_code = 8'hFF;
            endcase
        end
    end

    assign disp_an_o = enable_count ? 8'b1111_1110 : 8'b1111_1111;
    assign disp_seg_o = segment_code;

endmodule
