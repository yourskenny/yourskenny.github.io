﻿# 硬件验收记录：计组互认任务 4-5

## 任务 4：数码管固定显示

烧录文件：

```text
C:\coding\DLC\vivado_build\cpu_mutual_seg7_fixed\cpu_mutual_seg7_fixed.runs\impl_1\seg7_top_fixed_board.bit
```

验收现象：

- 释放复位后，8 位数码管稳定显示。
- 从左到右读数应为 `76543210`。

## 任务 5：矩形动画

烧录文件：

```text
C:\coding\DLC\vivado_build\cpu_mutual_rectangle_animation\cpu_mutual_rectangle_animation.runs\impl_1\rectangle_animation_top.bit
```

验收现象：

- `sw_i[0] = 0`：数码管熄灭，动画复位。
- `sw_i[0] = 1`：右侧四位数码管循环播放矩形动画。

## 判定

仿真通过、两个 bitstream 生成成功，并分别烧录后由板上现象确认，即可认为计组互认任务 4-5 完成。
