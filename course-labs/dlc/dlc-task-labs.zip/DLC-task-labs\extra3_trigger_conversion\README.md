﻿# 第三章兴趣拓展题 6：触发器功能转换

## 交付物

- `design_report.md`：三种转换的表格、方程和三工程拆分说明。
- `trigger_conversion.v`：核心触发器、三种转换模块、按钮单步外壳和三个板级顶层。
- `tb_trigger_conversion.v`：自检仿真。
- `trigger_conversion_board.xdc`：Nexys A7-100T 板级约束。
- `hardware_verification.md`：三个工程的硬件验证步骤与讲解词。

## 推荐仿真命令

```powershell
& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv trigger_conversion.v tb_trigger_conversion.v
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_trigger_conversion -s tb_trigger_conversion_sim
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' tb_trigger_conversion_sim -runall
```

期望输出：

```text
PASS: trigger conversion examples passed
```
