﻿# 设计说明：计组加分题贪吃蛇

## 任务目标

指导书中计组任务 6 要求在矩形变换的基础上完成贪吃蛇图例。本实现提供 25 帧动画，满足“至少完成 25 帧/排”的要求，并在输出端强制关闭 `dp` 小数点。

动画不采用整排铺亮的方式，而是手工设计 25 帧段码。每帧控制一条短蛇的头部、身体和尾部：蛇先沿顶部 `A` 段移动，再沿右侧下行，随后沿底部 `D` 段返回，最后通过左侧和中间段做回转。头部会额外点亮前进方向的相邻段，拐弯时形成明显的角，从视觉上更接近贪吃蛇图例。

## 模块结构

核心模块为 `snake_display`，板级顶层为 `snake_display_top`。顶层只暴露开发板需要的端口：

- `clk`：100 MHz 系统时钟。
- `rstn`：低有效复位。
- `sw_i[0]`：动画使能。
- `disp_an_o`：8 位数码管位选，低有效。
- `disp_seg_o`：七段数码管段选，低有效，位序为 `DPGFEDCBA`。

## 数据流

动画数据流：

```text
frame_index -> frame_segments -> selected_segment -> disp_seg_o
```

扫描数据流：

```text
scan_counter -> digit_index -> disp_an_o
digit_index -> frame_segments[8*digit_index +: 8] -> selected_segment
```

`frame_segments` 是 64 位帧数据，每 8 位对应一个数码管。`frame_segments[7:0]` 对应最右侧一位，`frame_segments[63:56]` 对应最左侧一位。帧表直接由 `frame_index` 选择，便于讲解和验收时逐帧对照。

## 小数点处理

题目要求去掉 `dp` 小点显示。由于 `disp_seg_o[7]` 是 `dp`，且段选低有效，最终输出写成：

```verilog
assign disp_seg_o = enable ? {1'b1, selected_segment[6:0]} : 8'hFF;
```

因此无论帧表内容如何，`dp` 都保持熄灭。

## 验收重点

讲解时重点说明三件事：一是动画至少 25 帧；二是每帧用 64 位段码控制 8 个数码管；三是 `dp` 由输出端统一屏蔽，符合题目要求。
