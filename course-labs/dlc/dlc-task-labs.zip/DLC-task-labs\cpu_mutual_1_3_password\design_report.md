﻿# 计组互认任务 1-3：密码检测、仿真与 LED 循环

## 1. 任务目标

本目录覆盖指导书第一章中的计组互认任务 1-3：

1. 基于密码检测黑箱电路查看 RTL 概要图。
2. 对密码检测电路进行仿真。
3. 在密码正确后，让 LED 从左至右循环点亮和熄灭，并完成仿真。

## 2. 密码检测电路

使用 `sw_i[3:0]` 输入 4 位二进制密码，预设密码为 `1010`。当输入正确时：

```text
password_ok = (sw_i[3:0] == 4'b1010)
```

输出使用 `led_o[15]`，对应开发板最左侧 LED。

## 3. LED 循环电路

当 `password_ok=1` 时，`password_led_chase` 模块启动分频计数，让点亮位置从 `led_o[15]` 依次移动到 `led_o[0]`，再回到 `led_o[15]`。当密码错误或复位时，全部 LED 熄灭，并把位置复位到 `led_o[15]`。

为了便于仿真，分频参数写成 `DIV_MAX`：

- 硬件默认：`DIV_MAX = 99_999_999`，约 1 秒一步。
- 仿真：`DIV_MAX = 5`，快速产生波形。

## 4. 互认讲解重点

- 任务 1：打开 synthesized design 或 RTL analysis，指出 `password_input`、比较器和 `led_o[15]` 输出。
- 任务 2：运行 `tb_blackbox_password_detector.v`，展示只有输入 `1010` 时输出为 1。
- 任务 3：运行 `tb_password_led_chase.v`，展示密码正确后 LED 位置随分频 tick 变化；仿真时说明分频系数改小是为了压缩波形时间。

## 5. 代码与验证文件

- `blackbox_password_detector.v`
- `tb_blackbox_password_detector.v`
- `blackbox_password_detector.xdc`
- `password_led_chase.v`
- `tb_password_led_chase.v`
- `password_led_chase.xdc`
- `hardware_verification.md`

硬件烧录时使用 `password_led_chase_top` 作为顶层；`debug_index` 只用于仿真观察，不作为开发板输出端口。
