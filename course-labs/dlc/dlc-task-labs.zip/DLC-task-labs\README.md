﻿# 数逻满分与计组互认任务总索引

本目录按统一范式组织：每个任务目录都包含 `design_report.md`、Verilog 源码、`tb_*.v` 自检仿真文件、`hardware_verification.md` 和 `README.md`。已上板任务还配有对应 `.xdc` 约束和 Vivado 自动构建脚本。

## 1. 数逻必做任务

| 任务 | 目录 | 目标 | 状态 |
| :--- | :--- | :--- | :--- |
| 必做 1 | `task1.1` | 举重裁判电路 | 已整理 |
| 必做 2 | `task1.2` | BCD 多输出组合逻辑 | 已整理 |
| 必做 3 | `task2.1_bcd_7seg_decoder` | BCD/七段译码器 | 已仿真、已上板 |
| 必做 4 | `task2.2_decimal_counter` | 0-9 十进制计数器 | 已仿真、已上板 |
| 必做 5 | `task3.1_101_detector` | 可重叠 101 序列检测器 | 已仿真、已上板 |

## 2. 数逻满分拓展任务

| 任务 | 目录 | 目标 | 状态 |
| :--- | :--- | :--- | :--- |
| 第三章兴趣拓展题 6 | `extra3_trigger_conversion` | 三种触发器转换 | 三个工程均已完成、已上板验证 |

## 3. 计组互认与加分任务

| 任务 | 目录 | 目标 | 状态 |
| :--- | :--- | :--- | :--- |
| 计组任务 1-3 | `cpu_mutual_1_3_password` | RTL 查看、密码仿真、密码正确后 LED 循环 | 已仿真、已上板 |
| 计组任务 4-5 | `cpu_mutual_4_5_seg_display` | 固定数值显示、矩形动画/数据流讲解 | 已仿真、已上板 |
| 计组任务 6 | `cpu_bonus_snake` | 25 帧贪吃蛇，去掉 `dp` 小点 | 已仿真、已上板 |

## 4. 推荐验收顺序

1. 先演示 5 个必做任务，保证数逻基础分。
2. 提交报告与源码，覆盖平台要求的报告源码部分。
3. 演示 `extra3_trigger_conversion` 的三种触发器转换，冲刺数逻满分。
4. 演示 `cpu_mutual_1_3_password` 与 `cpu_mutual_4_5_seg_display`，争取计组互认。
5. 演示 `cpu_bonus_snake`，作为计组加分题。

## 5. 关键脚本

- `scripts/vivado_build_task2_1_bcd_7seg.tcl`
- `scripts/vivado_build_task2_2_decimal_counter.tcl`
- `scripts/vivado_build_task3_1_101_detector.tcl`
- `scripts/vivado_build_extra3_trigger_conversion.tcl`
- `scripts/vivado_build_cpu_mutual_1_3_password.tcl`
- `scripts/vivado_build_cpu_mutual_4_5_seg_display.tcl`
- `scripts/vivado_build_cpu_bonus_snake.tcl`
- `scripts/vivado_program_bitstream.tcl`
