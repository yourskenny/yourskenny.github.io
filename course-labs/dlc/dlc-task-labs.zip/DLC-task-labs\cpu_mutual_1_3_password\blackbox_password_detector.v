`timescale 1ns / 1ps

// CPU mutual-recognition tasks 1/2:
// Black-box password detector. Password 1010 lights led_o[15].
module blackbox_password_detector(
    input [15:0] sw_i,
    output [15:0] led_o
);
    wire [3:0] password_input;
    wire password_ok;

    assign password_input = sw_i[3:0];
    assign password_ok = (password_input == 4'b1010);

    assign led_o[15] = password_ok;
    assign led_o[14:0] = 15'b0;
endmodule
