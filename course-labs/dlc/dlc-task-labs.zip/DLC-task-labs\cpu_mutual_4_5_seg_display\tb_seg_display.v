`timescale 1ns / 1ps

module tb_seg_display;
    reg clk;
    reg rstn;
    reg enable;
    wire [7:0] fixed_an;
    wire [7:0] fixed_seg;
    wire [2:0] fixed_addr;
    wire [3:0] fixed_nibble;
    wire [7:0] rect_an;
    wire [7:0] rect_seg;
    wire [3:0] rect_frame;
    wire [2:0] rect_addr;
    wire [63:0] rect_graphics_data;

    seg7_top_fixed #(
        .SCAN_DIV_MAX(1)
    ) fixed_uut (
        .clk(clk),
        .rstn(rstn),
        .disp_an_o(fixed_an),
        .disp_seg_o(fixed_seg),
        .debug_addr(fixed_addr),
        .debug_nibble(fixed_nibble)
    );

    rectangle_animation #(
        .STEP_DIV_MAX(3),
        .SCAN_DIV_MAX(1)
    ) rect_uut (
        .clk(clk),
        .rstn(rstn),
        .enable(enable),
        .disp_an_o(rect_an),
        .disp_seg_o(rect_seg),
        .debug_frame(rect_frame),
        .debug_addr(rect_addr),
        .debug_graphics_data(rect_graphics_data)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rstn = 0;
        enable = 0;
        #20;
        rstn = 1;

        repeat (4) @(posedge clk);
        if (fixed_addr === 3'bxxx || fixed_nibble > 4'd7) begin
            $display("FAIL: fixed display should scan digits 0-7");
            $finish;
        end
        if (fixed_an !== ~(8'b0000_0001 << fixed_addr)) begin
            $display("FAIL: fixed scanner anode mismatch");
            $finish;
        end

        enable = 1;
        @(posedge clk);
        if (rect_graphics_data !== 64'hFFFF_FFFF_C6F6_F6F0) begin
            $display("FAIL: rectangle frame 1 graphics data mismatch: %h", rect_graphics_data);
            $finish;
        end
        repeat (10) @(posedge clk);
        if (rect_frame !== 4'd2) begin
            $display("FAIL: rectangle animation should advance to frame 3, got %0d", rect_frame);
            $finish;
        end
        if (rect_graphics_data !== 64'hFFFF_FFFF_FFC6_F0FF) begin
            $display("FAIL: rectangle frame 3 graphics data mismatch: %h", rect_graphics_data);
            $finish;
        end
        if (rect_an !== ~(8'b0000_0001 << rect_addr)) begin
            $display("FAIL: rectangle scanner anode mismatch");
            $finish;
        end

        enable = 0;
        repeat (3) @(posedge clk);
        if (rect_frame !== 4'd0) begin
            $display("FAIL: rectangle animation should reset when disabled");
            $finish;
        end
        if (rect_graphics_data !== 64'hFFFF_FFFF_FFFF_FFFF) begin
            $display("FAIL: rectangle display should blank when disabled");
            $finish;
        end

        $display("PASS: seg display mutual tasks passed");
        $finish;
    end
endmodule
