`timescale 1ns / 1ps

module tb_bcd_7seg_decoder;
    reg [3:0] sw_i;
    wire [7:0] disp_an_o;
    wire [7:0] disp_seg_o;

    integer i;
    reg [7:0] expected_seg;

    bcd_7seg_decoder uut (
        .sw_i(sw_i),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o)
    );

    task check_digit;
        input [3:0] value;
        input [7:0] seg;
        begin
            sw_i = value;
            expected_seg = seg;
            #10;
            if (disp_an_o !== 8'b1111_1110 || disp_seg_o !== expected_seg) begin
                $display("FAIL: value=%0d expected an=%b seg=%h got an=%b seg=%h",
                         value, 8'b1111_1110, expected_seg, disp_an_o, disp_seg_o);
                $finish;
            end
        end
    endtask

    initial begin
        check_digit(4'd0, 8'hC0);
        check_digit(4'd1, 8'hF9);
        check_digit(4'd2, 8'hA4);
        check_digit(4'd3, 8'hB0);
        check_digit(4'd4, 8'h99);
        check_digit(4'd5, 8'h92);
        check_digit(4'd6, 8'h82);
        check_digit(4'd7, 8'hF8);
        check_digit(4'd8, 8'h80);
        check_digit(4'd9, 8'h90);

        for (i = 10; i < 16; i = i + 1) begin
            sw_i = i[3:0];
            #10;
            if (disp_seg_o !== 8'hFF) begin
                $display("FAIL: invalid value=%0d expected blank seg=FF got=%h", i, disp_seg_o);
                $finish;
            end
        end

        $display("PASS: bcd_7seg_decoder all cases passed");
        $finish;
    end
endmodule
