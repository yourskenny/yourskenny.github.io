`timescale 1ns / 1ps

module decimal_counter_top(
    input clk,
    input rstn,
    input [15:0] sw_i,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    wire [3:0] debug_count_unused;

    decimal_counter #(
        .DIV_MAX(27'd99_999_999)
    ) u_counter (
        .clk(clk),
        .rstn(rstn),
        .sw_i(sw_i),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_count(debug_count_unused)
    );
endmodule
