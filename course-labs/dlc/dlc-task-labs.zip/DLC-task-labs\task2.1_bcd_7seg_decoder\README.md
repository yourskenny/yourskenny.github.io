﻿# 任务 3：BCD/七段译码器

## 交付物

- `design_report.md`：译码表与设计说明。
- `bcd_7seg_decoder.v`：BCD 到七段数码管译码实现。
- `tb_bcd_7seg_decoder.v`：0-15 全覆盖自检仿真。
- `hardware_verification.md`：开发板验证步骤。

## 推荐仿真命令

```powershell
iverilog -g2012 -o tb_bcd_7seg_decoder.vvp bcd_7seg_decoder.v tb_bcd_7seg_decoder.v
vvp tb_bcd_7seg_decoder.vvp
```

期望输出：

```text
PASS: bcd_7seg_decoder all cases passed
```
