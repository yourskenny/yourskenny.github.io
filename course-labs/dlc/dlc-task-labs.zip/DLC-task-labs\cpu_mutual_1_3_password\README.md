﻿# 计组互认任务 1-3：密码检测与 LED 循环

## 交付物

- `blackbox_password_detector.v`：密码检测黑箱电路。
- `tb_blackbox_password_detector.v`：密码检测自检仿真。
- `blackbox_password_detector.xdc`：密码检测板级约束。
- `password_led_chase.v`：密码正确后 LED 从 `led_o[15]` 到 `led_o[0]` 循环点亮，硬件顶层为 `password_led_chase_top`。
- `tb_password_led_chase.v`：LED 循环自检仿真。
- `password_led_chase.xdc`：LED 循环板级约束。
- `design_report.md`：互认任务说明与讲解重点。
- `hardware_verification.md`：仿真、RTL 和硬件验证步骤。

## 推荐仿真命令

```powershell
& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv blackbox_password_detector.v tb_blackbox_password_detector.v
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_blackbox_password_detector -s tb_blackbox_password_detector_sim
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' tb_blackbox_password_detector_sim -runall

& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv password_led_chase.v tb_password_led_chase.v
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_password_led_chase -s tb_password_led_chase_sim
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' tb_password_led_chase_sim -runall
```

期望输出：

```text
PASS: blackbox_password_detector all cases passed
PASS: password_led_chase behavior passed
```
