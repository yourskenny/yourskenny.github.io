`timescale 1ns / 1ps

// Computer-organization bonus task: seven-segment snake animation.
// At least 25 frames are provided, and dp is always forced off.
module snake_display #(
    parameter STEP_DIV_MAX = 24'd9_999_999,
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    input enable,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o,
    output [4:0] debug_frame,
    output [2:0] debug_digit
);
    reg [23:0] step_counter;
    reg [15:0] scan_counter;
    reg [4:0] frame_index;
    reg [2:0] digit_index;
    reg [63:0] frame_segments;
    reg [7:0] selected_segment;

    assign debug_frame = frame_index;
    assign debug_digit = digit_index;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            step_counter <= 24'd0;
            frame_index <= 5'd0;
        end else if (!enable) begin
            step_counter <= 24'd0;
            frame_index <= 5'd0;
        end else if (step_counter == STEP_DIV_MAX) begin
            step_counter <= 24'd0;
            if (frame_index == 5'd24) begin
                frame_index <= 5'd0;
            end else begin
                frame_index <= frame_index + 5'd1;
            end
        end else begin
            step_counter <= step_counter + 24'd1;
        end
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            scan_counter <= 16'd0;
            digit_index <= 3'd0;
        end else if (scan_counter == SCAN_DIV_MAX) begin
            scan_counter <= 16'd0;
            digit_index <= digit_index + 3'd1;
        end else begin
            scan_counter <= scan_counter + 16'd1;
        end
    end

    always @(*) begin
        case (frame_index)
            5'd0:  frame_segments = 64'hFFFF_FFFF_FFBF_BEFE;
            5'd1:  frame_segments = 64'hFFFF_FFFF_FFFE_BEFE;
            5'd2:  frame_segments = 64'hFFFF_FFFF_FEFE_FEFE;
            5'd3:  frame_segments = 64'hFFFF_FFFE_FEFE_FEFE;
            5'd4:  frame_segments = 64'hFFFF_FEFE_FEFE_FEFF;
            5'd5:  frame_segments = 64'hFFFE_FEFE_FEFE_FFFF;
            5'd6:  frame_segments = 64'hFEFE_FEFE_FEFF_FFFF;
            5'd7:  frame_segments = 64'hFCFE_FEFE_FFFF_FFFF;
            5'd8:  frame_segments = 64'hF8FE_FEFF_FFFF_FFFF;
            5'd9:  frame_segments = 64'hF0FE_FFFF_FFFF_FFFF;
            5'd10: frame_segments = 64'hF0F7_FFFF_FFFF_FFFF;
            5'd11: frame_segments = 64'hF1F7_F7FF_FFFF_FFFF;
            5'd12: frame_segments = 64'hF3F7_F7F7_FFFF_FFFF;
            5'd13: frame_segments = 64'hF7F7_F7F7_F7FF_FFFF;
            5'd14: frame_segments = 64'hFFF7_F7F7_F7F7_FFFF;
            5'd15: frame_segments = 64'hFFFF_F7F7_F7F7_F7FF;
            5'd16: frame_segments = 64'hFFFF_FFF7_F7F7_F7F7;
            5'd17: frame_segments = 64'hFFFF_FFFF_F7F7_F7E7;
            5'd18: frame_segments = 64'hFFFF_FFFF_FFF7_F7C7;
            5'd19: frame_segments = 64'hFFFF_FFFF_FFFF_F7C6;
            5'd20: frame_segments = 64'hFFFF_FFFF_FFFF_BFC6;
            5'd21: frame_segments = 64'hFFFF_FFFF_FFBF_BFCE;
            5'd22: frame_segments = 64'hFFFF_FFFF_FFBF_BFDE;
            5'd23: frame_segments = 64'hFFFF_FFFF_FFBF_BFFE;
            5'd24: frame_segments = 64'hFFFF_FFFF_FFBF_BFFE;
            default: frame_segments = 64'hFFFF_FFFF_FFFF_FFFF;
        endcase
    end

    always @(*) begin
        case (digit_index)
            3'd0: selected_segment = frame_segments[7:0];
            3'd1: selected_segment = frame_segments[15:8];
            3'd2: selected_segment = frame_segments[23:16];
            3'd3: selected_segment = frame_segments[31:24];
            3'd4: selected_segment = frame_segments[39:32];
            3'd5: selected_segment = frame_segments[47:40];
            3'd6: selected_segment = frame_segments[55:48];
            3'd7: selected_segment = frame_segments[63:56];
        endcase
    end

    assign disp_an_o = enable ? ~(8'b0000_0001 << digit_index) : 8'hFF;
    assign disp_seg_o = enable ? {1'b1, selected_segment[6:0]} : 8'hFF;
endmodule

module snake_display_top #(
    parameter STEP_DIV_MAX = 24'd9_999_999,
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    input [0:0] sw_i,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    snake_display #(
        .STEP_DIV_MAX(STEP_DIV_MAX),
        .SCAN_DIV_MAX(SCAN_DIV_MAX)
    ) snake_display_inst (
        .clk(clk),
        .rstn(rstn),
        .enable(sw_i[0]),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_frame(),
        .debug_digit()
    );
endmodule
