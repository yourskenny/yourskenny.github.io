`timescale 1ns / 1ps

module tb_weightlifting_judge;
    reg [2:0] sw_i;
    wire [0:0] led_o;

    integer i;
    reg expected;

    weightlifting_judge uut (
        .sw_i(sw_i),
        .led_o(led_o)
    );

    initial begin
        for (i = 0; i < 8; i = i + 1) begin
            sw_i = i[2:0];
            #10;
            expected = sw_i[0] & (sw_i[1] | sw_i[2]);
            if (led_o[0] !== expected) begin
                $display("FAIL: sw_i=%b expected=%b got=%b", sw_i, expected, led_o[0]);
                $finish;
            end
        end

        $display("PASS: weightlifting_judge all input cases passed");
        $finish;
    end
endmodule
