`timescale 1ns / 1ps

module tb_blackbox_password_detector;
    reg [15:0] sw_i;
    wire [15:0] led_o;

    integer i;
    reg expected;

    blackbox_password_detector uut (
        .sw_i(sw_i),
        .led_o(led_o)
    );

    initial begin
        for (i = 0; i < 16; i = i + 1) begin
            sw_i = 16'b0;
            sw_i[3:0] = i % 16;
            #10;
            expected = (sw_i[3:0] == 4'b1010);
            if (led_o[15] !== expected) begin
                $display("FAIL: password=%b expected=%b got=%b", sw_i[3:0], expected, led_o[15]);
                $fatal;
            end
        end

        $display("PASS: blackbox_password_detector all cases passed");
        $finish;
    end
endmodule
