﻿# 任务 5：可重叠 101 序列检测器

## 交付物

- `design_report.md`：状态表、方程和设计说明。
- `sequence_101_detector.v`：D 触发器与序列检测器实现。
- `tb_sequence_101_detector.v`：`10101` 重叠检测自检仿真。
- `sequence_101_detector.xdc`：Nexys A7-100T 最小板级约束。
- `hardware_verification.md`：开发板验证步骤。

## 推荐仿真命令

```powershell
& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv sequence_101_detector.v tb_sequence_101_detector.v
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_sequence_101_detector -s tb_sequence_101_detector_sim
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' tb_sequence_101_detector_sim -runall
```

期望输出：

```text
PASS: sequence_101_detector behavior passed
```
