`timescale 1ns / 1ps

module tb_trigger_conversion;
    reg clk;
    reg rstn;
    reg d_in;
    reg t_in;
    reg j_in;
    reg k_in;
    wire q_t_by_d;
    wire q_jk_by_d;
    wire q_d_by_jk;

    trigger_conversion_top uut (
        .clk(clk),
        .rstn(rstn),
        .d_in(d_in),
        .t_in(t_in),
        .j_in(j_in),
        .k_in(k_in),
        .q_t_by_d(q_t_by_d),
        .q_jk_by_d(q_jk_by_d),
        .q_d_by_jk(q_d_by_jk)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rstn = 0;
        d_in = 0;
        t_in = 0;
        j_in = 0;
        k_in = 0;
        #20;
        rstn = 1;

        t_in = 1;
        @(posedge clk); #1;
        if (q_t_by_d !== 1'b1) begin
            $display("FAIL: D-built T flip-flop should toggle to 1");
            $finish;
        end
        @(posedge clk); #1;
        if (q_t_by_d !== 1'b0) begin
            $display("FAIL: D-built T flip-flop should toggle back to 0");
            $finish;
        end

        t_in = 0;
        @(posedge clk); #1;
        if (q_t_by_d !== 1'b0) begin
            $display("FAIL: T=0 should hold state");
            $finish;
        end

        j_in = 1; k_in = 0;
        @(posedge clk); #1;
        if (q_jk_by_d !== 1'b1) begin
            $display("FAIL: D-built JK set failed");
            $finish;
        end

        j_in = 0; k_in = 1;
        @(posedge clk); #1;
        if (q_jk_by_d !== 1'b0) begin
            $display("FAIL: D-built JK reset failed");
            $finish;
        end

        j_in = 1; k_in = 1;
        @(posedge clk); #1;
        if (q_jk_by_d !== 1'b1) begin
            $display("FAIL: D-built JK toggle failed");
            $finish;
        end

        d_in = 1;
        @(posedge clk); #1;
        if (q_d_by_jk !== 1'b1) begin
            $display("FAIL: JK-built D should capture 1");
            $finish;
        end

        d_in = 0;
        @(posedge clk); #1;
        if (q_d_by_jk !== 1'b0) begin
            $display("FAIL: JK-built D should capture 0");
            $finish;
        end

        $display("PASS: trigger conversion examples passed");
        $finish;
    end
endmodule
