`timescale 1ns / 1ps

module seg7_top_fixed #(
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o,
    output [2:0] debug_addr,
    output [3:0] debug_nibble
);
    wire [31:0] display_data;

    // addr0 maps to the rightmost digit, so the low nibble is displayed as 0.
    // The eight digits read left to right as 76543210.
    assign display_data = 32'h7654_3210;

    seg7x16 #(
        .SCAN_DIV_MAX(SCAN_DIV_MAX)
    ) display (
        .clk(clk),
        .rstn(rstn),
        .i_data(display_data),
        .i_blank(8'b0000_0000),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_addr(debug_addr),
        .debug_nibble(debug_nibble)
    );
endmodule

module seg7_top_fixed_board #(
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    seg7_top_fixed #(
        .SCAN_DIV_MAX(SCAN_DIV_MAX)
    ) fixed_display (
        .clk(clk),
        .rstn(rstn),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_addr(),
        .debug_nibble()
    );
endmodule
