﻿# 验证汇总

## 1. 当前状态

本项目已按“5 个必做 + 报告源码 + 第三章兴趣题 6 做满 3 种转换 + 计组任务 1-5 互认 + 贪吃蛇加分”的路线完成。

已经实际使用 Vivado Simulator、Vivado 综合实现和开发板烧录验证过的任务包括：

- 必做 3：BCD/七段译码器。
- 必做 4：十进制计数器。
- 必做 5：可重叠 101 序列检测器。
- 第三章兴趣拓展题 6：三种触发器转换。
- 计组互认任务 1-3：密码检测、仿真、密码正确后 LED 循环。
- 计组互认任务 4-5：数码管固定显示、矩形动画。
- 计组加分题：25 帧贪吃蛇。

必做 1、必做 2 已按范式整理报告、源码、仿真与验收说明；其中必做 2 对应已有 `lab1/project_2` 上板结果。

## 2. Vivado 仿真结果

以下任务在本机已使用 Vivado Simulator 跑通，关键输出如下：

| 任务 | 关键输出 |
| :--- | :--- |
| 必做 3 | `PASS: bcd_7seg_decoder behavior passed` |
| 必做 4 | `PASS: decimal_counter behavior passed` |
| 必做 5 | `PASS: sequence_101_detector behavior passed` |
| 第三章兴趣题 6 | `PASS: trigger_conversion behavior passed` |
| 计组任务 1-3 | `PASS: blackbox_password_detector behavior passed`、`PASS: password_led_chase behavior passed` |
| 计组任务 4-5 | `PASS: seg display mutual tasks passed` |
| 贪吃蛇加分题 | `PASS: snake_display behavior passed` |

## 3. 已生成并烧录的 bitstream

| 任务 | bitstream |
| :--- | :--- |
| 必做 3 | `C:\coding\DLC\vivado_build\task2_1_bcd_7seg\task2_1_bcd_7seg.runs\impl_1\bcd_7seg_decoder.bit` |
| 必做 4 | `C:\coding\DLC\vivado_build\task2_2_decimal_counter\task2_2_decimal_counter.runs\impl_1\decimal_counter_top.bit` |
| 必做 5 | `C:\coding\DLC\vivado_build\task3_1_101_detector\task3_1_101_detector.runs\impl_1\sequence_101_detector_top.bit` |
| 触发器转换工程 1 | `C:\coding\DLC\vivado_build\extra3_trigger_conversion_d_to_t\extra3_trigger_conversion_d_to_t.runs\impl_1\d_to_t_board_top.bit` |
| 触发器转换工程 2 | `C:\coding\DLC\vivado_build\extra3_trigger_conversion_d_to_jk\extra3_trigger_conversion_d_to_jk.runs\impl_1\d_to_jk_board_top.bit` |
| 触发器转换工程 3 | `C:\coding\DLC\vivado_build\extra3_trigger_conversion_jk_to_d\extra3_trigger_conversion_jk_to_d.runs\impl_1\jk_to_d_board_top.bit` |
| 计组任务 1-3 | `C:\coding\DLC\vivado_build\cpu_mutual_password_led_chase\cpu_mutual_password_led_chase.runs\impl_1\password_led_chase_top.bit` |
| 计组任务 4 固定显示 | `C:\coding\DLC\vivado_build\cpu_mutual_seg7_fixed\cpu_mutual_seg7_fixed.runs\impl_1\seg7_top_fixed_board.bit` |
| 计组任务 5 矩形动画 | `C:\coding\DLC\vivado_build\cpu_mutual_rectangle_animation\cpu_mutual_rectangle_animation.runs\impl_1\rectangle_animation_top.bit` |
| 计组任务 6 贪吃蛇 | `C:\coding\DLC\vivado_build\cpu_bonus_snake\cpu_bonus_snake.runs\impl_1\snake_display_top.bit` |

这些工程烧录时 Vivado 均返回过 `PROGRAM_DONE`。

## 4. 最终板上状态

当前开发板最后一次烧录的是计组加分题贪吃蛇：

```text
C:\coding\DLC\vivado_build\cpu_bonus_snake\cpu_bonus_snake.runs\impl_1\snake_display_top.bit
```

验收现象：

- `sw_i[0] = 0`：8 位数码管全灭，动画复位。
- `sw_i[0] = 1`：短蛇沿数码管段码路径循环移动。
- `dp` 小数点不亮。

## 5. 课堂展示提醒

- 每个任务展示前先打开对应目录的 `README.md` 和 `hardware_verification.md`。
- 计组互认任务重点讲清“数据流”：输入、状态/帧序号、译码/段码、输出。
- 贪吃蛇题强调“25 帧”“蛇身连续移动”“去掉 `dp` 小点”。
- 若老师要求重新烧录，使用 `scripts/vivado_program_bitstream.tcl` 加对应 bitstream 路径即可。
