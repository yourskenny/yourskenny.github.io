`timescale 1ns / 1ps

// 实验1 任务2：多输出组合逻辑电路设计 (BCD码检测)
// 根据数逻课程项目规范，严格执行先列真值表再化简的流程，
// 并且严禁直接在逻辑代码中使用约束文件变量(sw_i, led_o)。

module bcd_detector(
    input  [3:0] sw_i, // sw_i[3:0] 代表 4 位 BCD 码输入
    output [1:0] led_o // led_o[0] 代表 F1 (输入>3), led_o[1] 代表 F2 (输入<7)
);

    // 1. 根据红线警告，定义具有实际意义的内部变量名，避免直接使用 sw_i[x] 进行逻辑操作
    wire [3:0] bcd_in;   // 内部接收输入
    wire bcd_A, bcd_B, bcd_C, bcd_D; // 提取各位
    wire out_gt3; // F1: 输入大于3的判定结果
    wire out_lt7; // F2: 输入小于7的判定结果
    
    // 2. 将外部物理接口信号分配给内部变量
    assign bcd_in = sw_i[3:0];
    assign bcd_A = bcd_in[3]; // 高位
    assign bcd_B = bcd_in[2];
    assign bcd_C = bcd_in[1];
    assign bcd_D = bcd_in[0]; // 低位
    
    // 3. 逻辑实现：
    // 根据真值表化简得出：
    // F1 = A + B
    // F2 = ~A * ~(B*C*D)
    
    // 推荐用 Verilog 的逻辑门语句实现门电路功能
    
    // 实现 F1 (A + B)
    or (out_gt3, bcd_A, bcd_B);
    
    // 实现 F2
    // 首先求 B*C*D
    wire and_bcd;
    and (and_bcd, bcd_B, bcd_C, bcd_D);
    
    // 然后求 ~(B*C*D)
    wire not_and_bcd;
    not (not_and_bcd, and_bcd);
    
    // 求 ~A
    wire not_A;
    not (not_A, bcd_A);
    
    // 最后求 ~A * ~(B*C*D)
    and (out_lt7, not_A, not_and_bcd);
    
    // 4. 将逻辑结果输出到物理接口
    assign led_o[0] = out_gt3;
    assign led_o[1] = out_lt7;

endmodule
