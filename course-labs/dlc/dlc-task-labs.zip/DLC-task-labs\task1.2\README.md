﻿# 任务 2：BCD 码多输出组合逻辑电路

## 交付物

- `design_report.md`：题目分析、真值表、化简和变量映射。
- `bcd_detector.v`：门级/逻辑门 Verilog 实现。
- `tb_bcd_detector.v`：0-9 有效 BCD 自检仿真。
- `hardware_verification.md`：开发板测试步骤与验收讲解词。

## 推荐仿真命令

```powershell
iverilog -g2012 -o tb_bcd_detector.vvp bcd_detector.v tb_bcd_detector.v
vvp tb_bcd_detector.vvp
```

期望输出：

```text
PASS: bcd_detector valid BCD cases passed
```
