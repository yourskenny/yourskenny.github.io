`timescale 1ns / 1ps

// CPU mutual-recognition task 3:
// After password 1010 is entered, one LED moves from led_o[15] to led_o[0].
module password_led_chase #(
    parameter DIV_MAX = 27'd99_999_999
)(
    input clk,
    input rstn,
    input [15:0] sw_i,
    output [15:0] led_o,
    output [3:0] debug_index
);
    wire [3:0] password_input;
    wire password_ok;
    reg [26:0] div_counter;
    reg tick;
    reg [3:0] led_index;
    reg [15:0] led_pattern;

    assign password_input = sw_i[3:0];
    assign password_ok = (password_input == 4'b1010);
    assign debug_index = led_index;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            div_counter <= 27'd0;
            tick <= 1'b0;
        end else if (!password_ok) begin
            div_counter <= 27'd0;
            tick <= 1'b0;
        end else if (div_counter == DIV_MAX) begin
            div_counter <= 27'd0;
            tick <= 1'b1;
        end else begin
            div_counter <= div_counter + 27'd1;
            tick <= 1'b0;
        end
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            led_index <= 4'd15;
        end else if (!password_ok) begin
            led_index <= 4'd15;
        end else if (tick) begin
            if (led_index == 4'd0) begin
                led_index <= 4'd15;
            end else begin
                led_index <= led_index - 4'd1;
            end
        end
    end

    always @(*) begin
        if (!password_ok) begin
            led_pattern = 16'b0;
        end else begin
            led_pattern = (16'h0001 << led_index);
        end
    end

    assign led_o = led_pattern;
endmodule

module password_led_chase_top(
    input clk,
    input rstn,
    input [15:0] sw_i,
    output [15:0] led_o
);
    wire [3:0] unused_debug_index;

    password_led_chase u_chase (
        .clk(clk),
        .rstn(rstn),
        .sw_i(sw_i),
        .led_o(led_o),
        .debug_index(unused_debug_index)
    );
endmodule
