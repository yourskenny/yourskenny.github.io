﻿# 计组加分题：贪吃蛇

## 文件清单

- `snake_display.v`：25 帧七段数码管贪吃蛇动画，包含板级顶层 `snake_display_top`。
- `tb_snake_display.v`：自检仿真，检查帧推进、熄灭复位和 `dp` 小点关闭。
- `snake_display.xdc`：开发板管脚约束。
- `design_report.md`：设计说明与数据流讲解。
- `hardware_verification.md`：硬件验收步骤与讲解话术。

## 验证命令

```powershell
& 'C:\Xilinx\Vivado\2018.3\bin\xvlog.bat' -sv snake_display.v tb_snake_display.v
& 'C:\Xilinx\Vivado\2018.3\bin\xelab.bat' tb_snake_display -s tb_snake_display_sim
& 'C:\Xilinx\Vivado\2018.3\bin\xsim.bat' tb_snake_display_sim -runall
```

期望输出：

```text
PASS: snake_display behavior passed
```

## 上板观察

- `sw_i[0] = 0`：8 位数码管全灭，动画复位。
- `sw_i[0] = 1`：数码管循环播放 25 帧贪吃蛇动画。
- 任意状态下 `dp` 小数点不应点亮。
