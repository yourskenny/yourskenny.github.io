`timescale 1ns / 1ps

module dff_basic(
    input clk,
    input rstn,
    input d,
    output reg q
);
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            q <= 1'b0;
        end else begin
            q <= d;
        end
    end
endmodule

// Task 5: overlapped 101 sequence detector.
// BTNC is the single-step clock, sw_i[0] is the serial input, and
// led_o[0] holds the detection result after each button pulse.
module sequence_101_detector(
    input BTNC,
    input rstn,
    input [15:0] sw_i,
    output [15:0] led_o
);

    wire serial_input;
    wire state_q1;
    wire state_q0;
    wire next_q1;
    wire next_q0;
    wire detect_next;
    wire detect_q;

    assign serial_input = sw_i[0];

    // State encoding:
    // S0=00: no useful prefix
    // S1=01: prefix "1" has been observed
    // S2=10: prefix "10" has been observed
    assign next_q1 = state_q0 & (~serial_input);
    assign next_q0 = serial_input;
    assign detect_next = state_q1 & serial_input;

    dff_basic ff_q1 (
        .clk(BTNC),
        .rstn(rstn),
        .d(next_q1),
        .q(state_q1)
    );

    dff_basic ff_q0 (
        .clk(BTNC),
        .rstn(rstn),
        .d(next_q0),
        .q(state_q0)
    );

    dff_basic ff_detect (
        .clk(BTNC),
        .rstn(rstn),
        .d(detect_next),
        .q(detect_q)
    );

    assign led_o[0] = detect_q;
    assign led_o[15] = state_q1;
    assign led_o[14] = state_q0;
    assign led_o[13:1] = 13'b0;

endmodule
