﻿# 任务 1：举重裁判电路

## 交付物

- `design_report.md`：题目分析、真值表、化简和变量映射。
- `weightlifting_judge.v`：门级 Verilog 实现。
- `tb_weightlifting_judge.v`：自检仿真文件。
- `hardware_verification.md`：开发板测试步骤与验收讲解词。

## 推荐仿真命令

```powershell
iverilog -g2012 -o tb_weightlifting_judge.vvp weightlifting_judge.v tb_weightlifting_judge.v
vvp tb_weightlifting_judge.vvp
```

期望输出：

```text
PASS: weightlifting_judge all input cases passed
```
