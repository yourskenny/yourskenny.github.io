`timescale 1ns / 1ps

module tb_snake_display;
    reg clk;
    reg rstn;
    reg enable;
    wire [7:0] disp_an_o;
    wire [7:0] disp_seg_o;
    wire [4:0] debug_frame;
    wire [2:0] debug_digit;
    reg saw_last_frame;
    reg saw_wrap_after_last;

    snake_display #(
        .STEP_DIV_MAX(3),
        .SCAN_DIV_MAX(1)
    ) uut (
        .clk(clk),
        .rstn(rstn),
        .enable(enable),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_frame(debug_frame),
        .debug_digit(debug_digit)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rstn = 0;
        enable = 0;
        saw_last_frame = 0;
        saw_wrap_after_last = 0;
        #20;
        rstn = 1;

        enable = 1;
        repeat (120) begin
            @(posedge clk);
            #1;
            if (debug_frame == 5'd24) begin
                saw_last_frame = 1;
            end
            if (saw_last_frame && debug_frame == 5'd0) begin
                saw_wrap_after_last = 1;
            end
            if (disp_seg_o[7] !== 1'b1) begin
                $display("FAIL: dp segment should stay off, frame=%0d digit=%0d seg=%h",
                         debug_frame, debug_digit, disp_seg_o);
                $finish;
            end
        end

        if (!saw_last_frame || !saw_wrap_after_last) begin
            $display("FAIL: snake animation should reach frame 24 and wrap");
            $finish;
        end

        repeat (40) @(posedge clk);
        if (debug_frame > 5'd24) begin
            $display("FAIL: frame index out of range");
            $finish;
        end

        enable = 0;
        repeat (3) @(posedge clk);
        if (disp_an_o !== 8'hFF || disp_seg_o !== 8'hFF || debug_frame !== 5'd0) begin
            $display("FAIL: disabled snake should blank and reset");
            $finish;
        end

        $display("PASS: snake_display behavior passed");
        $finish;
    end
endmodule
