`timescale 1ns / 1ps

// 任务3：BCD/七段译码器
// 输入 0-9 时显示对应十进制数字，输入大于 9 时数码管全灭。

module bcd_7seg_decoder(
    input  [3:0] sw_i,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);

    wire [3:0] bcd_value;
    reg [7:0] segment_code;

    assign bcd_value = sw_i[3:0];

    always @(*) begin
        case (bcd_value)
            4'd0: segment_code = 8'hC0;
            4'd1: segment_code = 8'hF9;
            4'd2: segment_code = 8'hA4;
            4'd3: segment_code = 8'hB0;
            4'd4: segment_code = 8'h99;
            4'd5: segment_code = 8'h92;
            4'd6: segment_code = 8'h82;
            4'd7: segment_code = 8'hF8;
            4'd8: segment_code = 8'h80;
            4'd9: segment_code = 8'h90;
            default: segment_code = 8'hFF;
        endcase
    end

    // 数码管位选低电平有效。只点亮最右侧一位，满足“只能点亮1个数码管”的要求。
    assign disp_an_o = 8'b1111_1110;
    assign disp_seg_o = segment_code;

endmodule
