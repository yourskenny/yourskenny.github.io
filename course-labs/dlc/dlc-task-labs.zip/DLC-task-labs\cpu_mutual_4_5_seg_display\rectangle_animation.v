`timescale 1ns / 1ps

module rectangle_animation #(
    parameter STEP_DIV_MAX = 24'd9_999_999,
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    input enable,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o,
    output [3:0] debug_frame,
    output [2:0] debug_addr,
    output [63:0] debug_graphics_data
);
    reg [23:0] step_counter;
    reg [15:0] scan_counter;
    reg [2:0] seg7_addr;
    reg [3:0] frame_index;
    reg [31:0] frame_data;
    reg [7:0] an_reg;
    reg [7:0] seg_reg;
    wire [63:0] graphics_data;

    assign debug_frame = frame_index;
    assign debug_addr = seg7_addr;
    assign graphics_data = enable ? {32'hFFFF_FFFF, frame_data} : 64'hFFFF_FFFF_FFFF_FFFF;
    assign debug_graphics_data = graphics_data;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            step_counter <= 24'd0;
            frame_index <= 4'd0;
        end else if (!enable) begin
            step_counter <= 24'd0;
            frame_index <= 4'd0;
        end else if (step_counter == STEP_DIV_MAX) begin
            step_counter <= 24'd0;
            if (frame_index == 4'd13) begin
                frame_index <= 4'd0;
            end else begin
                frame_index <= frame_index + 4'd1;
            end
        end else begin
            step_counter <= step_counter + 24'd1;
        end
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            scan_counter <= 16'd0;
            seg7_addr <= 3'd0;
        end else if (scan_counter == SCAN_DIV_MAX) begin
            scan_counter <= 16'd0;
            seg7_addr <= seg7_addr + 3'd1;
        end else begin
            scan_counter <= scan_counter + 16'd1;
        end
    end

    always @(*) begin
        case (frame_index)
            4'd0:  frame_data = 32'hC6F6_F6F0;
            4'd1:  frame_data = 32'hF9F6_F6CF;
            4'd2:  frame_data = 32'hFFC6_F0FF;
            4'd3:  frame_data = 32'hFFC0_FFFF;
            4'd4:  frame_data = 32'hFFA3_FFFF;
            4'd5:  frame_data = 32'hFFFF_A3FF;
            4'd6:  frame_data = 32'hFFFF_9CFF;
            4'd7:  frame_data = 32'hFF9E_BCFF;
            4'd8:  frame_data = 32'hFF9C_FFFF;
            4'd9:  frame_data = 32'hFFC0_FFFF;
            4'd10: frame_data = 32'hFFA3_FFFF;
            4'd11: frame_data = 32'hFFA7_B3FF;
            4'd12: frame_data = 32'hFFC6_F0FF;
            4'd13: frame_data = 32'hF9F6_F6CF;
            default: frame_data = 32'hFFFF_FFFF;
        endcase

        an_reg = ~(8'b0000_0001 << seg7_addr);
        case (seg7_addr)
            3'd0: seg_reg = graphics_data[7:0];
            3'd1: seg_reg = graphics_data[15:8];
            3'd2: seg_reg = graphics_data[23:16];
            3'd3: seg_reg = graphics_data[31:24];
            3'd4: seg_reg = graphics_data[39:32];
            3'd5: seg_reg = graphics_data[47:40];
            3'd6: seg_reg = graphics_data[55:48];
            3'd7: seg_reg = graphics_data[63:56];
        endcase
    end

    assign disp_an_o = an_reg;
    assign disp_seg_o = seg_reg;
endmodule

module rectangle_animation_top #(
    parameter STEP_DIV_MAX = 24'd9_999_999,
    parameter SCAN_DIV_MAX = 16'd49_999
)(
    input clk,
    input rstn,
    input [0:0] sw_i,
    output [7:0] disp_an_o,
    output [7:0] disp_seg_o
);
    rectangle_animation #(
        .STEP_DIV_MAX(STEP_DIV_MAX),
        .SCAN_DIV_MAX(SCAN_DIV_MAX)
    ) rectangle_display (
        .clk(clk),
        .rstn(rstn),
        .enable(sw_i[0]),
        .disp_an_o(disp_an_o),
        .disp_seg_o(disp_seg_o),
        .debug_frame(),
        .debug_addr(),
        .debug_graphics_data()
    );
endmodule
