`timescale 1ns / 1ps

module tb_sequence_101_detector;
    reg BTNC;
    reg rstn;
    reg [15:0] sw_i;
    wire [15:0] led_o;

    sequence_101_detector uut (
        .BTNC(BTNC),
        .rstn(rstn),
        .sw_i(sw_i),
        .led_o(led_o)
    );

    task pulse_input;
        input bit_value;
        begin
            sw_i[0] = bit_value;
            #5;
            BTNC = 1'b1;
            #10;
            BTNC = 1'b0;
            #5;
        end
    endtask

    initial begin
        BTNC = 1'b0;
        rstn = 1'b0;
        sw_i = 16'b0;
        #20;
        rstn = 1'b1;

        pulse_input(1'b1);
        if (led_o[0] !== 1'b0) begin
            $display("FAIL: single 1 should not match");
            $finish;
        end

        pulse_input(1'b0);
        if (led_o[0] !== 1'b0) begin
            $display("FAIL: 10 should not match");
            $finish;
        end

        pulse_input(1'b1);
        if (led_o[0] !== 1'b1) begin
            $display("FAIL: 101 should match");
            $finish;
        end

        pulse_input(1'b0);
        if (led_o[0] !== 1'b0) begin
            $display("FAIL: 1010 should not match at last step");
            $finish;
        end

        pulse_input(1'b1);
        if (led_o[0] !== 1'b1) begin
            $display("FAIL: 10101 should match overlapping second 101");
            $finish;
        end

        rstn = 1'b0;
        #10;
        rstn = 1'b1;
        if (led_o[15:14] !== 2'b00) begin
            $display("FAIL: reset should clear state LEDs");
            $finish;
        end

        $display("PASS: sequence_101_detector behavior passed");
        $finish;
    end
endmodule
